#!/usr/bin/env bash
<<<<<<< HEAD
# Usage: bash deploy/lbg-push.sh [NEW_LBG_FEATURE_BRANCH]
# Destination base is LBG main_stage. Source is personal main.
# Preserve both contributors' history through the shared merge-based sync helper.
set -euo pipefail
script_dir=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
exec bash "$script_dir/lbg-sync.sh" push "$@"
=======

 echo "=== SETUP REMOTES ==="
git remote set-url origin git@github.com:Srujan-DiagonalMatrix/rove.git

if git remote get-url company >/dev/null 2>&1; then
  git remote set-url company git@github-company:lbg-cloud-platform/tactical-innovation-f2b97b.git
else
  git remote add company git@github-company:lbg-cloud-platform/tactical-innovation-f2b97b.git
fi

echo "=== FETCH LATEST ==="
git fetch origin main || exit 1
git fetch company main || exit 1

echo "=== SAVE LOCAL CHANGES IF ANY ==="
STASHED=0

if [ -n "$(git status --porcelain)" ]; then
  git stash push -u -m "bank-local-only-$(date +%Y%m%d-%H%M%S)"
  STASHED=1
fi

echo "=== CREATE NEW LBG FEATURE BRANCH ==="
FEATURE_BRANCH="feature/rove-sync-$(date +%Y%m%d-%H%M%S)"

git switch -c "$FEATURE_BRANCH" company/main || exit 1

echo "=== COPY PERSONAL ROVE MAIN ==="
git read-tree --reset -u origin/main

echo "=== KEEP ONLY BANK .github CONFIGURATION ==="
rm -rf .github
git checkout company/main -- .github 2>/dev/null || true

echo "=== REMOVE LOCAL-ONLY FILES ==="
rm -f \
  Dockerfile.backup \
  Dockerfile.backup.bak \
  Dockerfile.bak \
  Dockerfile.before-ca-fix \
  Dockerfile.web.bak \
  Dockerfile.web.backup.*.bak \
  server/Dockerfile.backup.*.bak \
  server/Dockerfile.bak \
  server/Dockerfile.bank-backup \
  company-ca.pem \
  docker-compose.corporate.yml

echo "=== COMMIT ==="
git add -A
git status --short

if git diff --cached --quiet; then
  echo "No new changes to commit."
else
  git commit -m "ROVE - GCP updated build" || exit 1
fi

echo "=== PUSH TO LBG ==="
git push -u company "$FEATURE_BRANCH" || exit 1

echo
echo "========================================"
echo "SUCCESS"
echo "========================================"
echo "LBG branch:"
echo "$FEATURE_BRANCH"
echo
echo "Create PR:"
echo "$FEATURE_BRANCH -> main"
echo

echo "=== RETURN TO PERSONAL MAIN ==="
git switch main

if [ "$STASHED" -eq 1 ]; then
  echo "=== RESTORE LOCAL BANK-LAPTOP CHANGES ==="
  git stash pop || true
fi

echo
echo "=== FINAL STATUS ==="
git status
>>>>>>> c8a84f2a4133c424fd40f08c39fcdd35ec298b73
