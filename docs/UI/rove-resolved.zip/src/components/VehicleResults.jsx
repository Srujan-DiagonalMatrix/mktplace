import { useEffect, useMemo, useRef, useState } from 'react';
import AosPlayer, { AOS_PUBLIC_DEMO_TOKEN } from './AosPlayer.jsx';
import { mapAosVehicleGallery } from './vehicleMedia.js';
import VehicleComingSoon from './VehicleComingSoon.jsx';
import { vehicleCardDisplay } from './vehicleCardFallbacks.js';
import { featureOptions, matchesFeatures } from './vehicleFeatures.js';
import {
  clearHomepageVehicleSearchFromUrl,
  hasIndicativeFinanceStartingPrice,
  homepageVehicleFilterStatus,
  homepageVehicleFiltersFromSearch,
  mergeSelectedVehicleFilters,
  normalizeVehicleFilterValue,
  syncJourneyVehicleFilters,
} from './homepageVehicleFilters.js';
import { vehicleImageUrl } from '../vehicleImages';

const money = (v, currency = 'GBP', maximumFractionDigits = 0) => new Intl.NumberFormat('en-GB', { style: 'currency', currency, maximumFractionDigits }).format(v);
const title = (v = '') => (v || '').replaceAll('_', ' ').replace(/\b\w/g, (c) => c.toUpperCase()).replace(/\bSuv\b/g, 'SUV');
const nameOf = (v) => vehicleCardDisplay(v).name;
const registrationOf = (vehicle) => [vehicle.registration, vehicle.registration_number, vehicle.registrationNumber,
  vehicle.reg_number, vehicle.auction_metadata?.reg_no]
  .find((value) => typeof value === 'string' && value.trim())?.trim().replace(/\s+/g, '').toUpperCase() || '';
const BCA_FILTER_FIELDS = ['Condition', 'Emission class', 'Insurance group', 'CO₂ emissions', 'Engine size', 'Battery kW'];
const inventoryField = (vehicle, label) => {
  const metadata = vehicle.auction_metadata || {};
  const values = {
    'Body type': metadata.body_type || vehicle.specification?.body_style || vehicle.vehicle_category,
    'Condition': vehicle.condition || metadata.condition,
    'Emission class': metadata.emission_class,
    'Insurance group': metadata.insurance_group,
    'CO₂ emissions': metadata.co2_emissions || vehicle.specification?.co2_g_km,
    'Engine size': metadata.engine_size,
    'Battery kW': metadata.battery_kw,
    Seats: metadata.seats || vehicle.specification?.seat_count,
  };
  return values[label];
};
const inventorySearchText = (vehicle) => [
  vehicle.registration, vehicle.stock_reference, vehicle.manufacturer, vehicle.model,
  vehicle.derivative, vehicle.colour, vehicle.fuel_type, vehicle.transmission,
  ...Object.values(vehicle.auction_metadata || {}),
].filter((value) => value != null).join(' ').toLocaleLowerCase();
export function Photo({ vehicle, name, token }) {
  const registration = registrationOf(vehicle);
  const requestKey = `${vehicle.id}|${registration}|${token || ''}`;
  const [media, setMedia] = useState({ key: null, images: [], loaded: false });
  const [failedUrls, setFailedUrls] = useState(() => new Set());
  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();
    const finish = images => { if (!cancelled) setMedia({ key: requestKey, images, loaded: true }); };
    setMedia({ key: requestKey, images: [], loaded: false });
    setFailedUrls(new Set());
    const timeout = window.setTimeout(() => { controller.abort(); finish([]); }, 15000);
    if (!registration) finish([]);
    else if (token) fetch(`https://br-api.aos.tv/vehicles/${encodeURIComponent(registration)}`, {
      headers: { Authorization: `Bearer ${token}` }, credentials: 'omit', signal: controller.signal,
    }).then(response => response.ok ? response.json() : null)
      .then(payload => finish(mapAosVehicleGallery(payload, vehicle)))
      .catch(() => finish([])).finally(() => window.clearTimeout(timeout));
    return () => { cancelled = true; window.clearTimeout(timeout); controller.abort(); };
  }, [vehicle.id, registration, token]);
  const matching = media.key === requestKey;
  const source = matching ? media.images.find(image => image.image_url && !failedUrls.has(image.image_url))?.image_url : null;
  if (!source && matching && media.loaded) return <VehicleComingSoon vehicle={vehicle} />;
  return <img src={source ? vehicleImageUrl(source) : undefined} alt={source ? name : ''} loading="lazy"
    onError={() => { if (source) setFailedUrls(current => new Set(current).add(source)); }} />;
}

export default function VehicleResults({ vehicles = [], focusVehicleId, selectedVehicle, onSelectVehicle, onViewDetails, selectionStatus, selectionSaving, planType = '', setPlanType, contractLength = '', setContractLength, homepageMonthlyRates = {}, journeyFilters = {}, aosToken: providedAosToken, onSelectionShownChange }) {
  const [fetchedAosToken, setFetchedAosToken] = useState(
    () => import.meta.env.VITE_AOS_TOKEN?.trim() || AOS_PUBLIC_DEMO_TOKEN
  );

  useEffect(() => {
    const controller = new AbortController();

    fetch('/api/catalogue/aos-token', { signal: controller.signal })
      .then((response) => {
        if (!response.ok) throw new Error('Token unavailable');
        return response.json();
      })
      .then((data) => {
        if (
          !controller.signal.aborted &&
          typeof data.token === 'string' &&
          data.token.trim()
        ) {
          setFetchedAosToken(data.token);
        }
      })
      .catch(() => {});

    return () => controller.abort();
  }, []);

  const effectiveAosToken = providedAosToken || fetchedAosToken;

  const [filters, setFilters] = useState(() => mergeSelectedVehicleFilters(homepageVehicleFiltersFromSearch(window.location.search), journeyFilters));
  const previousJourneyFilters = useRef(journeyFilters);
  const [draft, setDraft] = useState({});
  const [openToolbarDropdown, setOpenToolbarDropdown] = useState(null);
  const [mobileFilters, setMobileFilters] = useState(() => window.matchMedia('(max-width: 600px)').matches);
  const [openFilterSections, setOpenFilterSections] = useState({});
  const [visible, setVisible] = useState(6);
  const [sort, setSort] = useState('age-newest');
  const [favourites, setFavourites] = useState(() => {
    try { return new Set(JSON.parse(localStorage.getItem('rove.vehicleFavourites') || '[]')); } catch { return new Set(); }
  });
  const [favouritesOnly, setFavouritesOnly] = useState(false);
  const [quickVehicle, setQuickVehicle] = useState(null);
  const registrations = useMemo(() => new Map([...vehicles]
    .sort((a, b) => String(a.id).localeCompare(String(b.id)))
    .map((vehicle, index) => [vehicle.id, registrationOf(vehicle)
      || ''])), [vehicles]);
  const quickDialog = useRef(null);
  const filterDialog = useRef(null);
  const toolbarRef = useRef(null);
  const focused = useRef(null);
  useEffect(() => {
    const media = window.matchMedia('(max-width: 600px)');
    const updateMobileFilters = () => setMobileFilters(media.matches);
    media.addEventListener('change', updateMobileFilters);
    return () => media.removeEventListener('change', updateMobileFilters);
  }, []);
  useEffect(() => { setDraft(filters); }, [filters]);
  useEffect(() => {
    const previous = previousJourneyFilters.current;
    previousJourneyFilters.current = journeyFilters;
    setFilters((current) => syncJourneyVehicleFilters(current, previous, journeyFilters));
  }, [journeyFilters]);
  useEffect(() => {
    if (!openToolbarDropdown) return undefined;
    const closeOnOutsidePointer = (event) => {
      if (!toolbarRef.current?.contains(event.target)) setOpenToolbarDropdown(null);
    };
    const closeOnEscape = (event) => {
      if (event.key === 'Escape') setOpenToolbarDropdown(null);
    };
    document.addEventListener('pointerdown', closeOnOutsidePointer);
    document.addEventListener('keydown', closeOnEscape);
    return () => {
      document.removeEventListener('pointerdown', closeOnOutsidePointer);
      document.removeEventListener('keydown', closeOnEscape);
    };
  }, [openToolbarDropdown]);
  useEffect(() => {
    const vehicle = vehicles.find((item) => item.id === focusVehicleId);
    if (vehicle && focused.current !== focusVehicleId) {
      focused.current = focusVehicleId;
      setQuickVehicle(vehicle); quickDialog.current.showModal();
      // Consume the homepage deep link so returning from Finance does not
      // repeatedly reopen the original car's dialog.
      const url = new URL(window.location.href);
      url.searchParams.delete('vehicle');
      window.history.replaceState(null, '', url.pathname + url.search + url.hash);
    }
  }, [vehicles, focusVehicleId]);
  const features = useMemo(() => featureOptions(vehicles), [vehicles]);
  const options = useMemo(() => ({
    'Vehicle class': [...new Set(vehicles.map((v) => title(v.vehicle_type)).filter(Boolean))].sort(),
    'Vehicle type': [...new Set(vehicles.map((v) => inventoryField(v, 'Body type')).filter(Boolean).map(title))].sort(),
    Price: ['Under £15,000', '£15,000–£25,000', 'Over £25,000'],
    Mileage: ['Under 20,000', '20,000–40,000', 'Over 40,000'],
    Fuel: [...new Set(vehicles.map((v) => title(v.fuel_type)).filter(Boolean))].sort(),
    Transmission: [...new Set(vehicles.map((v) => title(v.transmission)).filter(Boolean))].sort(),
    Make: [...new Set(vehicles.map((v) => v.manufacturer).filter(Boolean))].sort(),
    Model: [...new Set(vehicles.filter((v) => !filters.Make?.length || filters.Make.some((make) => normalizeVehicleFilterValue(make) === normalizeVehicleFilterValue(v.manufacturer))).map((v) => v.model).filter(Boolean))].sort(),
    Doors: [...new Set(vehicles.map((v) => v.door_count).filter((value) => value != null).map(String))].sort((a, b) => Number(a) - Number(b)),
    Colour: [...new Set(vehicles.map((v) => v.colour).filter(Boolean))].sort(),
    Year: [...new Set(vehicles.map((v) => v.model_year).filter((value) => value != null).map(String))].sort((a, b) => Number(b) - Number(a)),
    Seats: [...new Set(vehicles.map((vehicle) => inventoryField(vehicle, 'Seats')).filter((value) => value != null && value !== '').map(String))].sort((a, b) => Number(a) - Number(b)),
    ...Object.fromEntries(BCA_FILTER_FIELDS.map((label) => [
      label,
      [...new Set(vehicles.map((vehicle) => inventoryField(vehicle, label)).filter((value) => value != null && value !== '').map(String))].sort((a, b) => Number(a) - Number(b) || a.localeCompare(b)),
    ])),
    Features: features.map((feature) => feature.code),
  }), [vehicles, features, filters.Make]);
  const results = useMemo(() => {
    const inventoryQuery = filters['Inventory search']?.[0]?.trim().toLocaleLowerCase();
    const matches = (key, values) => {
      const selected = filters[key];
      if (!selected?.length) return true;
      const candidates = (Array.isArray(values) ? values : [values]).filter((value) => value != null && value !== '');
      return selected.some((choice) => candidates.some((candidate) => {
        const normalizedChoice = normalizeVehicleFilterValue(choice);
        const normalizedCandidate = normalizeVehicleFilterValue(candidate);
        return key === 'Fuel' ? normalizedCandidate.includes(normalizedChoice) : normalizedCandidate === normalizedChoice;
      }));
    };
    const range = (key, value, low, high) => !filters[key]?.length || (value != null && filters[key].some((choice) => choice === options[key][0] ? value < low : choice === options[key][1] ? value >= low && value <= high : value > high));
    const recognizedSpecialRequirements = filters['Special requirements']?.length
      ? features.filter((feature) => filters['Special requirements'].some((query) => {
        const normalizedQuery = normalizeVehicleFilterValue(query);
        return normalizedQuery.includes(normalizeVehicleFilterValue(feature.name))
          || normalizedQuery.includes(normalizeVehicleFilterValue(feature.code));
      })).map((feature) => feature.code)
      : [];
    const filtered = vehicles.filter((v) => (!favouritesOnly || favourites.has(v.id))
      && homepageVehicleFilterStatus(v, filters) !== 'excluded'
      && matches('Vehicle class', title(v.vehicle_type))
      && matches('Vehicle type', [inventoryField(v, 'Body type'), v.vehicle_category])
      && matches('Fuel', title(v.fuel_type)) && matches('Transmission', title(v.transmission))
      && BCA_FILTER_FIELDS.every((field) => matches(field, inventoryField(v, field)))
      && (!inventoryQuery || inventorySearchText(v).includes(inventoryQuery))
      && matches('Model', v.model)
      && matches('Doors', v.door_count == null ? null : String(v.door_count))
      && matches('Colour', v.colour)
      && matches('Year', v.model_year == null ? null : String(v.model_year))
      && (!filters['Year from']?.length || (v.model_year != null && Number(v.model_year) >= Number(filters['Year from'][0])))
      && (!filters['Year to']?.length || (v.model_year != null && Number(v.model_year) <= Number(filters['Year to'][0])))
      && (!filters.Seats?.length || (inventoryField(v, 'Seats') != null && filters.Seats.some((seat) => Number(inventoryField(v, 'Seats')) === Number(seat))))
      && range('Price', Number(v.list_price), 15000, 25000) && range('Mileage', v.mileage, 20000, 40000)
      && matchesFeatures(v, filters.Features)
      && matchesFeatures(v, recognizedSpecialRequirements));
    return filtered.sort((a, b) => {
      const aUnverified = homepageVehicleFilterStatus(a, filters) === 'unverified' ? 1 : 0;
      const bUnverified = homepageVehicleFilterStatus(b, filters) === 'unverified' ? 1 : 0;
      if (aUnverified !== bUnverified) return aUnverified - bUnverified;
      const stableOrder = String(a.stock_reference || a.id).localeCompare(String(b.stock_reference || b.id));
      if (sort === 'age-newest') return (Number(b.model_year) || 0) - (Number(a.model_year) || 0) || stableOrder;
      if (sort === 'price-low') return Number(a.list_price) - Number(b.list_price) || stableOrder;
      if (sort === 'price-high') return Number(b.list_price) - Number(a.list_price) || stableOrder;
      if (sort === 'mileage') return (a.mileage ?? Infinity) - (b.mileage ?? Infinity) || stableOrder;
      return stableOrder;
    });
  }, [vehicles, filters, options, sort, favourites, favouritesOnly]);
  const budgetFilteringActive = filters['Monthly budget'] != null && filters['Monthly budget'] !== '';
  const verifiedBudgetResults = budgetFilteringActive
    ? results.filter((vehicle) => homepageVehicleFilterStatus(vehicle, filters) === 'match')
    : results;
  const unverifiedBudgetResults = budgetFilteringActive
    ? results.filter((vehicle) => homepageVehicleFilterStatus(vehicle, filters) === 'unverified')
    : [];
  const indicativeUnverifiedCount = unverifiedBudgetResults.filter((vehicle) => {
    return hasIndicativeFinanceStartingPrice(vehicle, homepageMonthlyRates);
  }).length;
  const visibleResults = results.slice(0, visible);
  const selectionShown = Boolean(selectedVehicle) && results.some((vehicle) => vehicle.stock_reference === selectedVehicle);
  useEffect(() => { onSelectionShownChange?.(selectionShown); }, [selectionShown, onSelectionShownChange]);
  const visibleVerifiedBudgetResults = budgetFilteringActive
    ? visibleResults.filter((vehicle) => homepageVehicleFilterStatus(vehicle, filters) === 'match')
    : [];
  const visibleUnverifiedBudgetResults = budgetFilteringActive
    ? visibleResults.filter((vehicle) => homepageVehicleFilterStatus(vehicle, filters) === 'unverified')
    : [];
  useEffect(() => { setVisible(6); }, [filters]);
  const toggle = (current, key, value) => ({ ...current, [key]: current[key]?.includes(value) ? current[key].filter((v) => v !== value) : [...(current[key] || []), value] });
  const setToolbarFilter = (key, value) => {
    setFilters((current) => {
      if (key === 'Vehicle type') {
        const isVehicleClass = Boolean(value) && vehicles.some((vehicle) => title(vehicle.vehicle_type).toLowerCase() === value.toLowerCase());
        return {
          ...current,
          'Vehicle type': isVehicleClass || !value ? [] : [value],
          'Vehicle class': isVehicleClass ? [value.toLowerCase()] : [],
        };
      }
      return { ...current, [key]: value ? [value] : [], ...(key === 'Make' ? { Model: [] } : {}) };
    });
    setVisible(6);
    setOpenToolbarDropdown(null);
  };
  const drawerYearOptions = options.Year;
  const drawerCategoryOptions = [...new Set(vehicles.filter((vehicle) => !draft['Vehicle class']?.length || draft['Vehicle class'].some((type) => normalizeVehicleFilterValue(type) === normalizeVehicleFilterValue(vehicle.vehicle_type))).map((vehicle) => inventoryField(vehicle, 'Body type')).filter(Boolean).map(title))].sort();
  const drawerModelOptions = [...new Set(vehicles.filter((vehicle) => !draft.Make?.length || draft.Make.some((make) => normalizeVehicleFilterValue(make) === normalizeVehicleFilterValue(vehicle.manufacturer))).map((vehicle) => vehicle.model).filter(Boolean))].sort();
  const drawerGroups = [
    { id: 'Vehicle type', label: 'Vehicle type' },
    { id: 'Vehicle category', label: 'Body type' },
    { id: 'Inventory search', label: 'Registration, VIN or inventory details' },
    ...BCA_FILTER_FIELDS.map((id) => ({ id, label: id })),
    { id: 'Fuel', label: 'Fuel type' },
    { id: 'Make & Model', label: 'Make & Model' },
    { id: 'Transmission', label: 'Transmission' },
    { id: 'Colour', label: 'Colour' },
    { id: 'Year of manufacture', label: 'Year of manufacture' },
    { id: 'Mileage', label: 'Mileage' },
    { id: 'Seats', label: 'Seats' },
    { id: 'Features', label: 'Extras & features' },
  ];
  const toggleToolbarDropdown = (key) => setOpenToolbarDropdown((current) => current === key ? null : key);
  const reset = () => {
    setFilters({}); setDraft({}); setFavouritesOnly(false); setVisible(6); setSort('age-newest');
    // Clear the homepage search parameters too, so a refresh after Clear all
    // does not silently restore the original homepage filters.
    const url = clearHomepageVehicleSearchFromUrl(window.location.href);
    window.history.replaceState(null, '', url.pathname + url.search + url.hash);
  };
  const favourite = (id) => setFavourites((current) => {
    const next = new Set(current); if (next.has(id)) next.delete(id); else next.add(id);
    try { localStorage.setItem('rove.vehicleFavourites', JSON.stringify([...next])); } catch { /* Retain in memory if storage is unavailable. */ }
    return next;
  });
  const select = (v) => onSelectVehicle({ ...v, stockReference: v.stock_reference });
  const vehicleChips = Object.entries(filters).flatMap(([key, values]) =>
    (Array.isArray(values) ? values : values == null || values === '' ? [] : [values])
      .map((value) => ({ key, value, label: key === 'Monthly budget' ? `£${value} monthly budget` : key === 'Year from' ? `From ${value}` : key === 'Year to' ? `To ${value}` : title(String(value)) })));
  const contractChips = [
    ...(planType ? [{ key: 'plan', value: planType, label: planType === 'Lease' ? 'Contract Hire' : planType === 'Purchase Agreement' ? 'Contract Purchase' : planType }] : []),
    ...(contractLength ? [{ key: 'term', value: contractLength, label: `${contractLength} Months` }] : []),
  ];
  const removeChip = ({ key, value }) => {
    if (key === 'plan') setPlanType?.('');
    else if (key === 'term') setContractLength?.('');
    else setFilters((current) => ({ ...current, [key]: Array.isArray(current[key]) ? current[key].filter((item) => item !== value) : '' }));
    setVisible(6);
  };
  const renderChip = (chip) => <button className="selection-filter-chip" type="button" key={`${chip.key}-${chip.value}`} aria-label={`Remove ${chip.label} filter`} onClick={() => removeChip(chip)}>{chip.label}<span aria-hidden="true">×</span></button>;
  const renderVehicleCard = (v) => {
    const card = vehicleCardDisplay(v, Math.max(0, results.indexOf(v)));
    const name = card.name;
    const selected = selectedVehicle === v.stock_reference;
    const photoCount = card.photoCount;
    const monthlyPayment = card.monthly;
    const reserved = card.isReserved;
    const has360 = (v.is_360_available ?? v.legacy_has_360) === true;
    return <article
      className={`selection-vehicle-card${selected ? ' selected' : ''}${reserved ? ' is-reserved' : ''}`}
      key={v.id}
      onClick={(event) => {
        if (event.target.closest('button, a, input, select, textarea, summary, [role="button"]')) return;
        select(v);
      }}
    >
      <button className="selection-detail-image-button" type="button" aria-label={`View details for ${name}`} onClick={(event) => { event.stopPropagation(); onViewDetails?.(v); }}>
        <span className="selection-vehicle-image">
          <Photo vehicle={v} name={name} token={effectiveAosToken} />
          {reserved && <span className="selection-reserved-message">This vehicle is reserved</span>}
        </span>
      </button>
      {has360 && <button
    className="selection-360-button"
    type="button"
    aria-label={`Open 360 degree tour for ${name}`}
    onClick={(event) => {
      event.stopPropagation();
      setQuickVehicle(v);
      if (!quickDialog.current.open) quickDialog.current.showModal();
    }}
  >
    360°
      </button>}
<button
  className="vehicle-select-area"
  type="button"
  aria-pressed={selected}
  onClick={() => select(v)}
>
        <strong>{name}</strong>
        <span className="selection-engine">{card.derivative}</span>
        <span className="selection-tags">
          <em>{title(card.vehicleType)}</em>
          <em>{title(card.fuelType)}</em>
          <em>{card.mileage == null ? '—' : `${card.mileage.toLocaleString('en-GB')} Miles`}</em>
          <em className="selection-registration">{card.year ?? '—'}</em>
        </span>
        <span className="selection-price">
          <span className="selection-price-item">
            <span className="selection-price-line"><b>{card.price == null ? '—' : new Intl.NumberFormat('en-GB', { style: 'currency', currency: card.currency, minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(card.price)}</b><small>{card.isSamplePrice ? 'Sample price' : 'RRP'}</small></span>
            <small className="selection-price-vat">{card.purchaseVat}</small>
          </span>
          <span className="selection-price-item">
            <span className="selection-price-line"><b>{monthlyPayment == null ? '—' : money(monthlyPayment, card.currency, Number.isInteger(monthlyPayment) ? 0 : 2)}</b><small>per month</small></span>
            <small className="selection-price-vat">{card.monthlyVat}</small>
          </span>
        </span>
      </button>
      <button className="selection-photo-count" type="button" aria-label={`View ${photoCount} photos and details for ${name}`} onClick={(event) => { event.stopPropagation(); onViewDetails?.(v); }}><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M5.1 3.1 6 2h4l.9 1.1h2.2c.6 0 1 .4 1 1v7.2c0 .6-.4 1-1 1H2.9c-.6 0-1-.4-1-1V4.1c0-.6.4-1 1-1h2.2Z"/><circle cx="8" cy="7.6" r="2.5"/></svg>{photoCount}</button>
    </article>;
  };

  return <section className="selection-results vehicle-selection-redesign" aria-labelledby="selection-results-title" aria-busy={selectionSaving}>
    <header className="selection-results-heading"><h1 id="selection-results-title">Vehicle Selection</h1><p>Explore vehicles and select one to continue with.</p></header>
    <div className="selection-filter-section">
    <div className="selection-filter-panel" ref={toolbarRef}>
    <div className="selection-filter-row" aria-label="Vehicle filters">
      {[
        ['Vehicle type', 'Vehicle'], ['Make', 'Make'], ['Model', 'Model'],
        ['Fuel', 'Fuel Type'], ['Mileage', 'Max Mileage'],
      ].map(([key, label]) => {
        const values = key === 'Vehicle type' ? [...new Set([...options['Vehicle class'], ...options['Vehicle type']])] : options[key];
        const currentValue = key === 'Vehicle type'
          ? filters['Vehicle class']?.[0] ? title(filters['Vehicle class'][0]) : filters['Vehicle type']?.[0] || ''
          : filters[key]?.[0] || '';
        return <div className={`catalogue-toolbar-dropdown${openToolbarDropdown === key ? ' is-open' : ''}`} data-filter={key} key={key}>
          <button className="catalogue-toolbar-trigger" type="button" aria-expanded={openToolbarDropdown === key} onClick={() => toggleToolbarDropdown(key)}>{label}<span aria-hidden="true" /></button>
          {openToolbarDropdown === key && <div className="catalogue-toolbar-menu" role="listbox" aria-label={key}>
            <button type="button" role="option" aria-selected={!currentValue} onClick={() => setToolbarFilter(key, '')}>{key === 'Make' ? 'All Makes' : key === 'Model' ? 'All Models' : 'Any'}</button>
            {values.map((value) => <button type="button" role="option" aria-selected={currentValue === value} key={value} onClick={() => setToolbarFilter(key, currentValue === value ? '' : value)}>{value}</button>)}
          </div>}
        </div>;
      })}
      <div className={`catalogue-toolbar-dropdown${openToolbarDropdown === 'Purchase' ? ' is-open' : ''}`} data-filter="Purchase">
        <button className="catalogue-toolbar-trigger" type="button" aria-expanded={openToolbarDropdown === 'Purchase'} onClick={() => toggleToolbarDropdown('Purchase')}>Contract Type<span aria-hidden="true" /></button>
        {openToolbarDropdown === 'Purchase' && <div className="catalogue-toolbar-menu" role="listbox" aria-label="Contract type">
          {[['Lease', 'Contract Hire'], ['Purchase Agreement', 'Contract Purchase'], ['Buy Outright', 'Buy Outright'], ['Not Sure', 'Not Sure']].map(([value, label]) => <button type="button" role="option" aria-selected={planType === value} key={value} onClick={() => { setPlanType?.(planType === value ? '' : value); setOpenToolbarDropdown(null); }}>{label}</button>)}
        </div>}
      </div>
    </div>
    <div className="selection-active-filters">
      <div className="selection-chip-group"><span>Vehicle</span><div>{vehicleChips.map(renderChip)}</div></div>
      <div className="selection-chip-group selection-contract-chips">
        <div className="catalogue-toolbar-dropdown">
          <button className="selection-contract-label" type="button" aria-label="Contract length" aria-expanded={openToolbarDropdown === 'Contract length'} onClick={() => toggleToolbarDropdown('Contract length')}>Contract</button>
          {openToolbarDropdown === 'Contract length' && <div className="catalogue-toolbar-menu" role="listbox" aria-label="Contract length">
            {[12, 24, 36, 48, 60].map((value) => <button type="button" role="option" aria-selected={String(value) === String(contractLength)} key={value} onClick={() => { setContractLength?.(String(value) === String(contractLength) ? '' : String(value)); setOpenToolbarDropdown(null); }}>{value} Months</button>)}
          </div>}
        </div>
        <div>{contractChips.map(renderChip)}</div>
      </div>
      <button className="all-filters" type="button" onClick={() => { setDraft(filters); setOpenToolbarDropdown(null); filterDialog.current.showModal(); }}>Advanced Filters <b>{vehicleChips.length + contractChips.length}</b><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 5h18M6 12h12M9 19h6" /></svg></button>
    </div>
    </div>
    </div>
    {selectionStatus && <p className="selection-save-status" role="status" aria-live="polite">{selectionStatus}</p>}
    <div className="selection-results-meta"><span className="selection-results-count" aria-live="polite">{results.length} {results.length === 1 ? 'Result' : 'Results'}{budgetFilteringActive && <small>{verifiedBudgetResults.length} within budget · {unverifiedBudgetResults.length} budget unverified</small>}</span><label><span>Sort by</span><select aria-label="Sort results" value={sort} onChange={(e) => { setSort(e.target.value); setVisible(6); }}><option value="age-newest">Age (newest)</option><option value="relevance">Relevance</option><option value="price-low">Price: low to high</option><option value="price-high">Price: high to low</option><option value="mileage">Lowest mileage</option></select></label></div>
    {budgetFilteringActive ? <>
      {!!visibleVerifiedBudgetResults.length && <>
        <section className="recommended-vehicles" aria-labelledby="recommended-title"><header><h2 id="recommended-title">Within budget</h2></header>
          <div className="selection-vehicle-grid">{visibleVerifiedBudgetResults.slice(0, Math.min(3, visibleVerifiedBudgetResults.length)).map(renderVehicleCard)}</div>
        </section>
        <div className="selection-vehicle-grid catalogue-vehicle-grid">{visibleVerifiedBudgetResults.slice(3).map(renderVehicleCard)}</div>
      </>}
      {!!unverifiedBudgetResults.length && <section className="budget-unverified-results" aria-labelledby="budget-unverified-title">
        <header><h2 id="budget-unverified-title">Budget unverified ({unverifiedBudgetResults.length})</h2>
          <p>These vehicles match your other filters, but no personalized monthly finance payment is available to confirm they are within budget.{indicativeUnverifiedCount > 0 ? ` ${indicativeUnverifiedCount} have indicative starting prices only; those are not treated as confirmed payments.` : ''}</p></header>
        {visibleUnverifiedBudgetResults.length
          ? <div className="selection-vehicle-grid">{visibleUnverifiedBudgetResults.map(renderVehicleCard)}</div>
          : <p>Use See More to load these vehicles.</p>}
      </section>}
    </> : <>
      {!!visibleResults.length && <div className="selection-vehicle-grid catalogue-vehicle-grid">{visibleResults.map(renderVehicleCard)}</div>}
    </>}
    {!results.length && <div className="catalogue-empty"><p>{vehicles.length ? 'No vehicles match these filters.' : 'No vehicles loaded. Complete Vehicle Needs first, or check the connection to the catalogue.'}</p>{vehicles.length > 0 && <button type="button" onClick={reset}>Clear filters</button>}</div>}
    {visible < results.length && <button className="selection-see-more" type="button" aria-label="See more vehicles" onClick={() => setVisible((count) => count + 6)}>See More</button>}
    <dialog ref={filterDialog} className="catalogue-dialog vehicle-filter-drawer" aria-labelledby="catalogue-filters-title" onClick={(event) => {
      if (event.target !== event.currentTarget) return;
      const bounds = event.currentTarget.getBoundingClientRect();
      if (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) {
        event.currentTarget.close();
      }
    }}>
      <header><h2 id="catalogue-filters-title">Filter</h2><button type="button" aria-label="Close filters" onClick={() => filterDialog.current.close()}>×</button></header>
      <div className="vehicle-filter-sections">
        {drawerGroups.map(({ id, label }) => <details
          className="vehicle-filter-section"
          key={id}
          open={openFilterSections[id] ?? mobileFilters}
          onToggle={(event) => {
            const isOpen = event.currentTarget.open;
            setOpenFilterSections((current) => ({ ...current, [id]: isOpen }));
          }}
        >
          <summary><span>{label}</span><span className="vehicle-filter-chevron" aria-hidden="true" /></summary>
          <div className={`vehicle-filter-options${id === 'Year of manufacture' || id === 'Mileage' || id === 'Make & Model' ? ' vehicle-filter-select-options' : ''}`}>
            {id === 'Vehicle type' && (options['Vehicle class'].length ? options['Vehicle class'].map((value) => <label key={value}><input type="radio" name="drawer-vehicle-class" checked={draft['Vehicle class']?.[0] === value.toLowerCase()} onChange={() => setDraft((current) => ({ ...current, 'Vehicle class': [value.toLowerCase()] }))} />{value}</label>) : <p>No options available.</p>)}
            {id === 'Vehicle category' && (drawerCategoryOptions.length ? drawerCategoryOptions.map((value) => <label key={value}><input type="checkbox" checked={draft['Vehicle type']?.includes(value) || false} onChange={() => setDraft((current) => toggle(current, 'Vehicle type', value))} />{value}</label>) : <p>No options available.</p>)}
            {id === 'Fuel' && (options.Fuel.length ? options.Fuel.map((value) => <label key={value}><input type="checkbox" checked={draft.Fuel?.includes(value) || false} onChange={() => setDraft((current) => toggle(current, 'Fuel', value))} />{value}</label>) : <p>No options available.</p>)}
            {id === 'Transmission' && (options.Transmission.length ? options.Transmission.map((value) => <label key={value}><input type="checkbox" checked={draft.Transmission?.includes(value) || false} onChange={() => setDraft((current) => toggle(current, 'Transmission', value))} />{value}</label>) : <p>No options available.</p>)}
            {id === 'Colour' && (options.Colour.length ? options.Colour.map((value) => <label key={value}><input type="checkbox" checked={draft.Colour?.includes(value) || false} onChange={() => setDraft((current) => toggle(current, 'Colour', value))} />{value}</label>) : <p>No options available.</p>)}
            {id === 'Make & Model' && <div className="vehicle-filter-make-model"><label>Make<select aria-label="Make" value={draft.Make?.[0] || ''} onChange={(event) => setDraft((current) => ({ ...current, Make: event.target.value ? [event.target.value] : [], Model: [] }))}><option value="">Any</option>{options.Make.map((value) => <option key={value} value={value}>{value}</option>)}</select></label><label>Model<select aria-label="Model" value={draft.Model?.[0] || ''} onChange={(event) => setDraft((current) => ({ ...current, Model: event.target.value ? [event.target.value] : [] }))}><option value="">Any</option>{drawerModelOptions.map((value) => <option key={value} value={value}>{value}</option>)}</select></label></div>}
            {id === 'Year of manufacture' && <div className="vehicle-filter-year-range"><label>From<select aria-label="Year from" value={draft['Year from']?.[0] || ''} onChange={(event) => setDraft((current) => { const next = event.target.value; const to = current['Year to']?.[0]; return { ...current, 'Year from': next ? [next] : [], 'Year to': next && to && Number(next) > Number(to) ? [] : current['Year to'] || [] }; })}><option value="">Any</option>{drawerYearOptions.map((value) => <option key={`from-${value}`} value={value}>{value}</option>)}</select></label><label>To<select aria-label="Year to" value={draft['Year to']?.[0] || ''} onChange={(event) => setDraft((current) => { const next = event.target.value; const from = current['Year from']?.[0]; return { ...current, 'Year to': next ? [next] : [], 'Year from': next && from && Number(next) < Number(from) ? [] : current['Year from'] || [] }; })}><option value="">Any</option>{drawerYearOptions.map((value) => <option key={`to-${value}`} value={value}>{value}</option>)}</select></label></div>}
            {id === 'Mileage' && <label>Mileage<select aria-label="Mileage" value={draft.Mileage?.[0] || ''} onChange={(event) => setDraft((current) => ({ ...current, Mileage: event.target.value ? [event.target.value] : [] }))}><option value="">Any</option>{options.Mileage.map((value) => <option key={value} value={value}>{value}</option>)}</select></label>}
            {id === 'Seats' && <>{['Any', ...options.Seats].map((value) => <label key={value}><input type="checkbox" checked={value === 'Any' ? !draft.Seats?.length : draft.Seats?.includes(value) || false} onChange={() => setDraft((current) => value === 'Any' ? { ...current, Seats: [] } : toggle({ ...current, Seats: current.Seats?.filter((seat) => seat !== 'Any') || [] }, 'Seats', value))} />{value === 'Any' ? 'Any' : value}</label>)}</>}
            {id === 'Features' && (features.length
              ? features.map((feature) => <label key={feature.code}><input type="checkbox" checked={draft.Features?.includes(feature.code) || false} onChange={() => setDraft((current) => toggle(current, 'Features', feature.code))} />{feature.name}</label>)
              : <p>No options available.</p>)}
            {id === 'Inventory search' && <label className="vehicle-inventory-search">Search<input type="search" value={draft['Inventory search']?.[0] || ''} placeholder="Registration, VIN, CAP ID, make, model…" onChange={(event) => setDraft((current) => ({ ...current, 'Inventory search': event.target.value ? [event.target.value] : [] }))} /></label>}
            {BCA_FILTER_FIELDS.includes(id) && (options[id]?.length
              ? options[id].map((value) => <label key={value}><input type="checkbox" checked={draft[id]?.includes(value) || false} onChange={() => setDraft((current) => toggle(current, id, value))} />{value}</label>)
              : <p>No options available.</p>)}
          </div>
        </details>)}
      </div>
      <footer>
        <button type="button" onClick={() => {
          setDraft({});
          setFilters({});
          setPlanType?.('');
          setContractLength?.('');
          setVisible(6);
          const url = clearHomepageVehicleSearchFromUrl(window.location.href);
          window.history.replaceState(window.history.state, '', url.pathname + url.search + url.hash);
        }}>Clear all</button>
        <button type="button" onClick={() => { setFilters(draft); setVisible(6); filterDialog.current.close(); }}>Apply</button>
      </footer>
    </dialog>
    <dialog ref={quickDialog} className="catalogue-dialog vehicle-tour-dialog" onClose={() => setQuickVehicle(null)} aria-labelledby="vehicle-tour-title">{quickVehicle && <>
      <header><h2 id="vehicle-tour-title">360° Tour · {nameOf(quickVehicle)}</h2><button type="button" aria-label="Close 360 degree tour" onClick={() => quickDialog.current.close()}>×</button></header>
      <AosPlayer key={quickVehicle.id} registration={registrations.get(quickVehicle.id)} token={effectiveAosToken} />
    </>}</dialog>
  </section>;
}

