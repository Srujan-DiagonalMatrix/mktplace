import { useEffect, useMemo, useRef, useState } from 'react';
import { vehicleImageUrl } from '../vehicleImages';
import { mapAosVehicleFeatureImages, mapAosVehicleGallery, mapAosVehicleVideo } from './vehicleMedia.js';
import { createVehicleDetailPreview, detailPreviewContent } from './vehicleDetailPreview.js';
import lloydsAuto from '../assets/vehicle-detail/lloyds-auto.svg';
import ProviderAttribution from './ProviderAttribution.jsx';
import './FullVehicleDetails.css';
import VehicleComingSoon from './VehicleComingSoon.jsx';

const aosRegistration = value => typeof value === 'string' ? value.trim().replace(/\s+/g, '').toUpperCase() : '';
const safeDestination = value => typeof value === 'string' && (/^https?:\/\//i.test(value) || /^\/(?!\/)/.test(value));

function Image({ image, vehicle, onError, pending = false }) {
  const [failedUrl, setFailedUrl] = useState(null);
  const source = image?.image_url && failedUrl !== image.image_url ? image : null;
  if (!source) return pending ? <img alt="" /> : <VehicleComingSoon vehicle={vehicle} />;
  return <img src={vehicleImageUrl(source.image_url)} alt={source.alt_text || `${vehicle.manufacturer} ${vehicle.model}`} loading="lazy"
    onError={() => { setFailedUrl(source.image_url); onError?.(); }} />;
}

export default function FullVehicleDetails({ vehicle, onBack, mediaRegistration, mediaToken, financeQuotes = [], selectedFinanceProduct, onSelectFinance, financeSaving = false }) {
  const view = useMemo(() => createVehicleDetailPreview(vehicle, financeQuotes), [vehicle, financeQuotes]);
  const registration = aosRegistration(mediaRegistration || vehicle.registration || vehicle.registration_number
    || vehicle.registrationNumber || vehicle.reg_number || vehicle.auction_metadata?.reg_no);
  const requestKey = `${vehicle.id}|${registration}|${mediaToken || ''}`;
  const [aosMedia, setAosMedia] = useState({ key: null, loaded: false, images: [], featureImages: [], videoUrl: null });
  const [activeImage, setActiveImage] = useState(0);
  const [failedGalleryUrls, setFailedGalleryUrls] = useState(() => new Set());
  const [galleryOpen, setGalleryOpen] = useState(false);
  const [standaloneImage, setStandaloneImage] = useState(null);
  const [documentTitle, setDocumentTitle] = useState(null);
  const [financeChoice, setFinanceChoice] = useState(null);
  const [financeNotice, setFinanceNotice] = useState('');
  const [videoStarted, setVideoStarted] = useState(false);
  const galleryDialog = useRef(null);
  const documentDialog = useRef(null);
  const video = useRef(null);
  useEffect(() => {
    setActiveImage(0);
    setFailedGalleryUrls(new Set());
    setGalleryOpen(false);
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, [vehicle.id]);
  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();
    const finish = payload => {
      if (!cancelled) setAosMedia({ key: requestKey, loaded: true,
        images: mapAosVehicleGallery(payload, vehicle), featureImages: mapAosVehicleFeatureImages(payload, vehicle),
        videoUrl: mapAosVehicleVideo(payload) });
    };
    setAosMedia({ key: requestKey, loaded: false, images: [], featureImages: [], videoUrl: null });
    const timeout = window.setTimeout(() => { controller.abort(); finish(null); }, 15000);
    if (!registration) finish(null);
    else if (mediaToken) fetch(`https://br-api.aos.tv/vehicles/${encodeURIComponent(registration)}`, {
      headers: { Authorization: `Bearer ${mediaToken}` }, credentials: 'omit', signal: controller.signal,
    }).then(response => response.ok ? response.json() : null).then(finish)
      .catch(() => finish(null)).finally(() => window.clearTimeout(timeout));
    return () => { cancelled = true; window.clearTimeout(timeout); controller.abort(); };
  }, [vehicle.id, registration, mediaToken]);

  const matchingAosMedia = aosMedia.key === requestKey ? aosMedia : null;
  useEffect(() => { setFailedGalleryUrls(new Set()); }, [vehicle.id, matchingAosMedia?.images]);
  const actualImages = (matchingAosMedia?.images || []).filter(image => image.image_url && !failedGalleryUrls.has(image.image_url));
  const images = actualImages;
  const mediaPending = !matchingAosMedia?.loaded;
  const selectedIndex = images.length ? Math.min(activeImage, images.length - 1) : 0;
  const selectedImage = images[selectedIndex] || null;
  const videoUrl = matchingAosMedia?.videoUrl || undefined;
  const featureMedia = matchingAosMedia?.featureImages || [];
  useEffect(() => {
    if (!galleryOpen) return undefined;
    const handleGalleryKeys = (event) => {
      if (event.key === 'Escape') setGalleryOpen(false);
      if (!standaloneImage && images.length > 1 && event.key === 'ArrowRight') setActiveImage((current) => (current + 1) % images.length);
      if (!standaloneImage && images.length > 1 && event.key === 'ArrowLeft') setActiveImage((current) => (current + images.length - 1) % images.length);
    };
    window.addEventListener('keydown', handleGalleryKeys);
    return () => window.removeEventListener('keydown', handleGalleryKeys);
  }, [galleryOpen, images.length, standaloneImage]);
  const failGalleryImage = (imageUrl) => {
    setFailedGalleryUrls((current) => new Set(current).add(imageUrl));
    setActiveImage(0);
  };

  useEffect(() => {
    setFinanceChoice(null); setFinanceNotice(''); setVideoStarted(false);
    setDocumentTitle(null); setStandaloneImage(null);
  }, [vehicle.id]);
  useEffect(() => {
    const dialog = galleryDialog.current;
    if (galleryOpen && !dialog.open) dialog.showModal();
    if (!galleryOpen && dialog.open) dialog.close();
  }, [galleryOpen]);
  useEffect(() => {
    const dialog = documentDialog.current;
    if (documentTitle && !dialog.open) dialog.showModal();
    if (!documentTitle && dialog.open) dialog.close();
  }, [documentTitle]);
  const openPhoto = (image = null) => { setStandaloneImage(image); setGalleryOpen(true); };
  const documentAction = (label, url) => safeDestination(url)
    ? <a href={url} target="_blank" rel="noreferrer">{label}</a>
    : <button className="full-detail-text-link" type="button" onClick={() => setDocumentTitle(label)}>{label}</button>;
  useEffect(() => { setFinanceChoice(null); }, [selectedFinanceProduct]);
  const selectedKey = financeChoice || view.finance.find(option => option.quote?.finance_product_id && option.quote.finance_product_id === selectedFinanceProduct)?.key
    || null;
  const chooseFinance = async option => {
    if (option.quote?.id && onSelectFinance) {
      const result = await onSelectFinance(option.quote);
      if (result !== false) setFinanceChoice(option.key);
      setFinanceNotice(result === false ? 'Unable to save this finance selection. Please try again.' : `${option.title} selected.`);
    } else {
      setFinanceChoice(option.key);
    }
  };
  const photoCount = actualImages.length;
  const galleryImage = standaloneImage || selectedImage;
  const photoCountLabel = `${actualImages.length} photos`;

  return <>
    <main className="full-vehicle-details" aria-label={`Full details for ${view.title}`} data-vehicle-id={vehicle.id}>
      <button type="button" className="full-detail-back" onClick={onBack}>← Back to results</button>
      <article className="full-detail-sheet">
        <section className="full-detail-hero" aria-label="Vehicle photos and finance preview">
          <div className="full-detail-gallery">
            <div className="full-detail-main-image">
              <button type="button" className="full-detail-image-trigger" aria-label={`Open photo gallery for ${view.title}`} onClick={() => openPhoto()}>
                <Image image={selectedImage} vehicle={vehicle} pending={mediaPending} onError={() => failGalleryImage(selectedImage?.image_url)} />
              </button>
              <button type="button" className="full-detail-photo-count" aria-label={photoCountLabel} onClick={() => openPhoto()}>
                <svg aria-hidden="true" viewBox="0 0 18 18"><path d="M2.5 5.5h3l1-1.5h5l1 1.5h3v8h-13z"/><circle cx="9" cy="9.5" r="2.3"/></svg>{photoCount}
              </button>
            </div>
            <div className="full-detail-thumbnails" aria-label="Choose vehicle photo">
              {images.slice(1, 5).map((image, index) => <button type="button" key={image.id || image.image_url} aria-label={`Show photo ${index + 2}${image.isSample ? ' (sample)' : ''}`} aria-pressed={selectedIndex === index + 1} onClick={() => setActiveImage(index + 1)}><Image image={image} vehicle={vehicle} onError={() => failGalleryImage(image.image_url)} /></button>)}
            </div>
          </div>
          <div className="full-detail-info-row">
            <div className="full-detail-title-price"><h1>{view.title}</h1><p className="full-detail-derivative">{view.derivative}</p></div>
            <div className="full-detail-rrp"><strong>{view.price}</strong><span>RRP</span><small>{view.vat}</small></div>
          </div>
          <div className="full-detail-finance-video">
            <div>
              <div className="full-detail-finance-options" aria-label="Finance options">
                {view.finance.map(option => <article className={`full-detail-finance-card${selectedKey === option.key ? ' is-selected' : ''}`} data-sample={option.isSample} key={option.key}>
                  <h2>{option.title}</h2>
                  <dl className="full-detail-finance-rows"><div><dt>{option.key === 'buy-outright' ? 'Price context' : 'Per month'}</dt><dd>{option.monthly}</dd></div><div><dt>Upfront</dt><dd>{option.upfront}</dd></div></dl>
                  <dl className="full-detail-finance-totalrow"><div className="full-detail-finance-total"><dt>Total</dt><dd>{option.total}</dd></div></dl>
                  <ProviderAttribution productKey={option.key} />
                  <button type="button" aria-label={`${selectedKey === option.key ? 'Selected' : 'Select'} ${option.title}`} aria-pressed={selectedKey === option.key} disabled={financeSaving} onClick={() => chooseFinance(option)}>{selectedKey === option.key ? '✓ Selected' : 'Select'}</button>
                </article>)}
              </div>
              {financeNotice && <p className="full-detail-finance-notice" role="status">{financeNotice}</p>}
            </div>
            <div className="full-detail-video-preview">
              <div className="full-detail-video-frame">
<video
  key={`${vehicle.id}-${videoUrl}`}
  ref={video}
  className="full-detail-video"
  controls={videoStarted}
  preload="metadata"
  aria-label={`${view.title} vehicle video`}
  poster={selectedImage?.image_url ? vehicleImageUrl(selectedImage.image_url) : undefined}
  onPlay={() => setVideoStarted(true)}
>
  {videoUrl && <source src={videoUrl} type="video/mp4" />}
  Vehicle video preview
</video>
{videoUrl && !videoStarted && (
  <button
    type="button"
    className="full-detail-video-play"
    aria-label="Play vehicle video"
    onClick={() => {
      setVideoStarted(true);
      video.current.play().catch(() => setVideoStarted(false));
    }}
  >
    <span aria-hidden="true">
      <svg viewBox="0 0 24 24" width="20" height="20">
        <path d="M7 4v16l13-8z" fill="currentColor" />
      </svg>
    </span>
  </button>
)}
              </div>
            </div>
          </div>
        </section>

        <section className="full-detail-summary"><h2>Vehicle Summary</h2><div>{view.summary.map(([label, value]) => <div key={label}><strong>{value}</strong><span>{label}</span></div>)}</div></section>
        <div className="full-detail-overview">{view.information.map(panel => <section className="full-detail-information-panel" key={panel.title}><h3>{panel.title}</h3><div className="full-detail-card"><dl>{panel.rows.map(([label, value]) => <div key={label}><dt>{label}</dt><dd className={label === 'Safety rating' ? 'full-detail-safety-rating' : undefined}>{value}</dd></div>)}</dl>{panel.link && documentAction(panel.link, panel.url)}</div></section>)}</div>

        <section className="full-detail-inspection"><h2>Vehicle Inspection</h2><div className="full-detail-inspection-grid">
          <article className="full-detail-inspection-intro"><h3>Pre-purchase check</h3><p>{view.inspection.summary}</p>{documentAction('View full report', view.inspection.reportUrl)}</article>
          <article className="full-detail-inspection-findings"><h3>Inspection Findings</h3><div className="full-detail-finding"><div><strong>{view.inspection.verified}</strong><b>Verified</b></div><p>{view.inspection.verifiedNote}</p></div></article>
          <article className="full-detail-inspection-findings"><h3>Imperfections</h3><div className="full-detail-finding"><div><strong>{view.inspection.noted}</strong><b>Noted</b></div><p>{view.inspection.notedNote}</p></div></article>
          <article className="full-detail-inspection-photos"><h3>Imperfections media</h3><button type="button" aria-label="Open inspection image" onClick={() => openPhoto(null)}><Image image={null} vehicle={vehicle} pending={mediaPending} /><span aria-hidden="true">⌕</span></button></article>
        </div></section>


        <div className="full-detail-lower-grid">
          <section className="full-detail-specs"><h2>Interior Specs</h2><div className="full-detail-spec-body"><dl className="full-detail-spec-tiles">{view.interior.map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}</dl><div className="full-detail-entertainment"><h3>Entertainment</h3><ul>{view.entertainment.map((text, index) => <li key={`${index}-${text}`}>{text}</li>)}</ul></div></div></section>
          <section className="full-detail-specs"><h2>Storage &amp; Capacity</h2><div className="full-detail-spec-body"><dl className="full-detail-spec-tiles">{view.storage.map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}</dl><div className="full-detail-dimension-row"><h3>Vehicle Dimensions</h3><dl className="full-detail-dimensions">{view.dimensions.map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}</dl></div></div></section>
        </div>

        <section className="full-detail-care full-detail-card" aria-label="Sample Extended Care Package">
          <div className="full-detail-care-intro"><img className="full-detail-brand-logo" src={lloydsAuto} alt="Lloyds Auto" /><h2>Extended Care Package</h2><p>{view.care.description}</p>{documentAction('View full coverage terms', view.care.termsUrl)}</div>
          {view.care.sections.map(column => <div className="full-detail-care-column" key={column.title}><h3>{column.title}</h3><ul>{column.items.map(item => <li key={item}>{item}</li>)}</ul></div>)}
        </section>
        <section className="full-detail-delivery full-detail-card" aria-labelledby="full-detail-delivery-title"><img className="full-detail-brand-logo" src={lloydsAuto} alt="Lloyds Auto" /><div><h2 id="full-detail-delivery-title">Your vehicle delivery</h2><strong>{view.delivery.estimate}</strong><p>{view.delivery.description}</p></div></section>
      </article>

      <dialog ref={galleryDialog} className="full-detail-gallery-viewer" aria-label={`${view.title} photo gallery`} onCancel={() => setGalleryOpen(false)} onClose={() => setGalleryOpen(false)} onClick={event => { if (event.target === event.currentTarget) setGalleryOpen(false); }}>
        {galleryOpen && <><button type="button" className="full-detail-gallery-close" aria-label="Close photo gallery" onClick={() => setGalleryOpen(false)}>×</button>
        {!standaloneImage && images.length > 1 && <button type="button" className="full-detail-gallery-previous" aria-label="Previous photo" onClick={() => setActiveImage((selectedIndex + images.length - 1) % images.length)}>‹</button>}
        <figure><Image image={galleryImage} vehicle={vehicle} pending={mediaPending} /><figcaption>{standaloneImage ? galleryImage?.alt_text : (images.length ? `${selectedIndex + 1} of ${images.length}` : '')}</figcaption></figure>
        {!standaloneImage && images.length > 1 && <button type="button" className="full-detail-gallery-next" aria-label="Next photo" onClick={() => setActiveImage((selectedIndex + 1) % images.length)}>›</button>}</>}
      </dialog>
      <dialog ref={documentDialog} className="full-detail-document-preview" aria-labelledby="full-detail-document-title" onCancel={() => setDocumentTitle(null)} onClose={() => setDocumentTitle(null)}><h2 id="full-detail-document-title">{documentTitle}</h2><p>{detailPreviewContent.documents[documentTitle]}</p><button type="button" onClick={() => setDocumentTitle(null)}>Close sample preview</button></dialog>
    </main>
    <footer className="full-detail-legal-footer"><nav aria-label="Legal information">{[['Cookie policy', '/cookie-policy'], ['Terms of use', '/terms-of-use'], ['Privacy policy', '/privacy-notice']].map(([label, href]) => <a key={label} href={href}>{label}</a>)}</nav>{detailPreviewContent.legal.map(text => <p key={text}>{text}</p>)}</footer>
  </>;
}

