import { useCallback, useEffect, useRef, useState } from 'react';
import { csvCell, INVENTORY_HEADERS } from './inventoryTemplate.js';
import AdminVehicles from './AdminVehicles.jsx';
import AdminBca360 from './AdminBca360.jsx';
import AdminContractPurchase from './AdminContractPurchase.jsx';
import AdminUsedContractHire from './AdminUsedContractHire.jsx';
import lloydsAuto from '../assets/vehicle-detail/lloyds-auto.svg';
import './AdminDashboard.css';
import './AdminDataPanel.css';
import AdminDonutReports from './AdminDonutReports.jsx';

const API = (import.meta.env.VITE_API_URL || '').replace(/\/$/, '');

const submissionMonth = new Intl.DateTimeFormat('en-GB', { month: 'short', year: 'numeric', timeZone: 'UTC' });

function quotedAmount(value) {
  if (value == null || value === '') return null;
  const amount = Number(value);
  return Number.isFinite(amount) && amount >= 0 ? Math.round(amount * 100) : null;
}

function reservationPipeline(records, preferredCurrency) {
  const active = records.filter(record => record.has_active_reservation
    && ['submitted', 'processing'].includes(record.status));
  const quoted = active.map(record => {
    const quote = record.selections || {};
    return {
      record,
      quote,
      currency: quote.currency,
      total: quotedAmount(quote.bundle_total) ?? quotedAmount(quote.total_payable),
    };
  }).filter(item => item.total != null && /^[A-Z]{3}$/.test(item.currency || ''));
  const currencies = [...new Set(quoted.map(item => item.currency))].sort();
  const currency = currencies.includes(preferredCurrency) ? preferredCurrency : currencies[0] || 'GBP';
  const currencyFormat = new Intl.NumberFormat('en-GB', { style: 'currency', currency });
  const formatter = pennies => currencyFormat.format(pennies / 100);
  const visible = quoted.filter(item => item.currency === currency);
  const product = ({ quote }) => quote.finance_product_name;
  const chart = (title, group, amount = item => item.total) => {
    const totals = new Map();
    for (const item of visible) {
      const value = amount(item);
      if (value == null) continue;
      const label = group(item) || 'Not recorded';
      totals.set(label, (totals.get(label) || 0) + value);
    }
    return { title, formatter, slices: [...totals].map(([label, value]) => ({ label, value })) };
  };

  return {
    activeCount: active.length,
    quotedCount: visible.length,
    currency,
    currencies,
    charts: [
      chart('Potential contract value by product and status', ({ quote, record }) =>
        [quote.finance_product_name, record.status?.replaceAll('_', ' ')].filter(Boolean).join(' · ')),
      chart('Potential contract value by reservation and month', ({ record }) => {
        const reservation = ({
          '48_hours': '48 hours', '30_days': '30 days', buy_now: 'Buy now',
        })[record.reservation_type];
        const time = Date.parse(record.submitted_at);
        const month = Number.isFinite(time) ? submissionMonth.format(time) : null;
        return [reservation, month].filter(Boolean).join(' · ');
      }),
      chart('Potential contract value by term and fuel type', ({ quote }) =>
        [quote.term_months && `${quote.term_months} months`, quote.vehicle_fuel_type]
          .filter(Boolean).join(' · ')),
      (() => {
        const totals = new Map();
        for (const item of visible) {
          for (const [kind, raw] of [['Monthly', item.quote.monthly_payment], ['Upfront', item.quote.upfront_payment]]) {
            const value = quotedAmount(raw);
            if (value == null) continue;
            const label = `${product(item) || "Not recorded"} · ${kind}`;
            totals.set(label, (totals.get(label) || 0) + value);
          }
        }
        return { title: 'Potential monthly and upfront payments by product', formatter, slices: [...totals].map(([label, value]) => ({ label, value })) };
      })(),
    ],
  };
}

const applicationDate = new Intl.DateTimeFormat('en-GB', { dateStyle: 'medium', timeStyle: 'short' });

function snapshotDetails(value, label) {
  if (value == null) return null;
  return <details><summary>{label}</summary><pre className="admin-application-snapshot">{JSON.stringify(value, null, 2)}</pre></details>;
}

const APPLICATION_COLUMNS = [
  ['submitted_at', 'Submitted date & time', record => applicationDate.format(new Date(record.submitted_at))],
  ['full_name', 'Customer'],
  ['customer_id', 'Customer ID'],
  ['application_id', 'Application ID'],
  ['contact_email', 'Email'],
  ['phone_number', 'Phone'],
  ['company_name', 'Company'],
  ['role', 'Role'],
  ['reservation_type', 'Reservation', record => record.reservation_type?.replaceAll('_', ' ')],
  ['status', 'Status'],
  ['has_active_reservation', 'Active reservation', record =>
    record.has_active_reservation == null ? null : (record.has_active_reservation ? 'Yes' : 'No')],
  ...[
    ['vehicle_id', 'Vehicle ID'],
    ['vehicle_name', 'Vehicle'],
    ['vehicle_derivative', 'Derivative'],
    ['vehicle_mileage', 'Vehicle mileage'],
    ['vehicle_fuel_type', 'Fuel type'],
    ['finance_product_name', 'Finance product'],
    ['term_months', 'Term (months)'],
    ['annual_mileage', 'Annual mileage'],
    ['currency', 'Quote currency'],
    ['monthly_payment', 'Monthly payment'],
    ['upfront_payment', 'Upfront payment'],
    ['total_payable', 'Total payable'],
    ['bundle_total', 'Bundle total'],
    ['potential_savings', 'Potential savings'],
    ['services', 'Services', record => snapshotDetails(record.selections?.services, 'View services')],
    ['application_summary', 'Application summary', record => snapshotDetails(record.selections?.application_summary, 'View summary')],
    ['agreement', 'Agreement', record => snapshotDetails(record.selections?.agreement, 'View agreement')],
  ].map(([key, label, render]) => [key, label, render || (record => record.selections?.[key])]),
];

const DEFAULT_APPLICATION_COLUMNS = APPLICATION_COLUMNS.slice(0, 10).map(([key]) => key);

function applicationValue(record, key) {
  return Object.hasOwn(record, key) ? record[key] : record.selections?.[key];
}

function downloadApplicationDetails(records) {
  const headers = APPLICATION_COLUMNS.map(([, label]) => label);
  const rows = records.map(record => APPLICATION_COLUMNS.map(([key]) => {
    const value = applicationValue(record, key);
    const text = value != null && typeof value === 'object' ? JSON.stringify(value) : String(value ?? '');
    return /^[\t\r\n]|^\s*[=+@-]/.test(text) ? "'" + text : text;
  }));
  const csv = [headers, ...rows].map(row => row.map(csvCell).join(',')).join('\r\n') + '\r\n';
  const url = URL.createObjectURL(new Blob(['\uFEFF', csv], { type: 'text/csv;charset=utf-8' }));
  const link = document.createElement('a');
  link.href = url;
  link.download = 'rove-customer-application-details.csv';
  link.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function DetailFields({ fields }) {
  return <dl className="admin-application-detail-fields">
    {fields.map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value ?? '—'}</dd></div>)}
  </dl>;
}

function snapshotFields(value, prefix = '') {
  if (value == null || typeof value !== 'object') {
    return [[prefix, typeof value === 'boolean' ? (value ? 'Yes' : 'No') : value]];
  }
  const entries = Object.entries(value);
  if (!entries.length) return [[prefix || 'Details', '—']];
  return entries.flatMap(([key, child]) => {
    const label = Array.isArray(value) ? String(Number(key) + 1) : key.replaceAll('_', ' ');
    return snapshotFields(child, prefix ? `${prefix} / ${label}` : label);
  });
}

const DETAIL_GROUPS = [
  [
    ['Customer', ['full_name', 'customer_id', 'contact_email', 'phone_number', 'company_name', 'role']],
    ['Application & reservation', ['application_id', 'submitted_at', 'status', 'reservation_type', 'has_active_reservation']],
  ],
  [
    ['Vehicle', ['vehicle_name', 'vehicle_id', 'vehicle_derivative', 'vehicle_mileage', 'vehicle_fuel_type']],
    ['Finance', ['finance_product_name', 'term_months', 'annual_mileage', 'currency', 'monthly_payment', 'upfront_payment', 'total_payable', 'bundle_total', 'potential_savings']],
  ],
];

function ApplicationDetailsDialog({ record, onClose }) {
  const dialog = useRef(null);
  useEffect(() => { dialog.current.showModal(); }, []);

  return <dialog ref={dialog} className="admin-application-dialog" aria-labelledby="customer-detail-title"
    onClose={onClose} onClick={event => {
      if (event.target === event.currentTarget) event.currentTarget.close();
    }}>
    <div className="admin-application-dialog-inner">
      <header className="admin-application-dialog-heading">
        <div><p>Application details</p><h2 id="customer-detail-title">{record.full_name || 'Customer application'}</h2></div>
        <button type="button" onClick={() => dialog.current.close()}>Close</button>
      </header>
      <div className="admin-application-detail-columns">
        {DETAIL_GROUPS.map(groups => <div key={groups[0][0]}>
          {groups.map(([title, keys]) => <section key={title}>
            <h3>{title}</h3>
            <DetailFields fields={APPLICATION_COLUMNS.filter(([key]) => keys.includes(key)).map(([key, label, render]) => [
              label, render ? render(record) : applicationValue(record, key),
            ])} />
          </section>)}
        </div>)}
      </div>
      {APPLICATION_COLUMNS.filter(([key]) => ['services', 'application_summary', 'agreement'].includes(key))
        .map(([key, label]) => <section className="admin-application-detail-section" key={key}>
          <h3>{label}</h3>
          <DetailFields fields={snapshotFields(applicationValue(record, key), label)} />
        </section>)}
    </div>
  </dialog>;
}

export default function AdminDashboard() {
  const [credentials, setCredentials] = useState({ username: '', password: '' });
  const [authenticated, setAuthenticated] = useState(null);
  const [records, setRecords] = useState([]);
  const [selectedApplications, setSelectedApplications] = useState([]);
  const [deletingApplications, setDeletingApplications] = useState(false);
  const [pipelineCurrency, setPipelineCurrency] = useState('GBP');
  const [search, setSearch] = useState('');
  const [applicationFilters, setApplicationFilters] = useState({ status: '', reservation: '', dateFrom: '', dateTo: '' });
  const [advancedOpen, setAdvancedOpen] = useState(false);
  const [applicationColumnKeys, setApplicationColumnKeys] = useState(DEFAULT_APPLICATION_COLUMNS);
  const applicationColumns = APPLICATION_COLUMNS.filter(([key]) => applicationColumnKeys.includes(key));
  const [activeTab, setActiveTab] = useState('inventory');
  const [importOpen, setImportOpen] = useState(false);
  const [selected, setSelected] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [inventoryFile, setInventoryFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [inventoryMessage, setInventoryMessage] = useState('');
  const [inventoryError, setInventoryError] = useState('');
  const [inventoryPreview, setInventoryPreview] = useState(null);
  const [selectedInventoryRows, setSelectedInventoryRows] = useState([]);
  const [inventoryRevision, setInventoryRevision] = useState(0);
  const recordsQuery = useRef('');
  const expireSession = useCallback(() => setAuthenticated(false), []);
  const uploadInventory = async (dryRun, selectedRows = []) => {
    if (!inventoryFile || uploading) return;
    setUploading(true); setInventoryError(''); setInventoryMessage('');
    try {
      const query = new URLSearchParams({ filename: inventoryFile.name, dry_run: String(dryRun) });
      if (!dryRun && selectedRows.length) query.set('selected_rows', selectedRows.join(','));
      const response = await fetch(`${API}/api/admin/inventory?${query}`, { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/octet-stream' }, body: inventoryFile });
      const result = await response.json().catch(() => ({}));
      if (response.status === 401) { setAuthenticated(false); throw new Error('Your admin session expired. Please sign in again.'); }
      if (!response.ok) throw new Error(result.detail || 'Unable to import inventory.');
      setInventoryMessage(result.message);
      if (dryRun) {
        setInventoryPreview({ headers: result.headers || [], rows: result.rows || [] });
        setSelectedInventoryRows((result.rows || []).filter(row => row.valid).map(row => row.row_number));
      } else {
        setInventoryRevision(value => value + 1);
        setInventoryPreview(null);
        setSelectedInventoryRows([]);
        setInventoryFile(null);
      }
    } catch (failure) { setInventoryError(failure.message); }
    finally { setUploading(false); }
  };

  const downloadPreviewSelection = () => {
    if (!inventoryPreview) return;
    const rows = inventoryPreview.rows.filter(row => selectedInventoryRows.includes(row.row_number));
    if (!rows.length) return;
    const csv = [inventoryPreview.headers, ...rows.map(row => row.values)]
      .map(row => row.map(csvCell).join(',')).join('\r\n') + '\r\n';
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
    const link = document.createElement('a');
    link.href = url; link.download = 'rove-inventory-selected.csv'; link.click();
    URL.revokeObjectURL(url);
  };

  const deletePreviewSelection = () => {
    if (!inventoryPreview) return;
    const removed = new Set(selectedInventoryRows);
    setInventoryPreview(current => ({ ...current, rows: current.rows.filter(row => !removed.has(row.row_number)) }));
    setSelectedInventoryRows([]);
    setInventoryMessage('Selected rows removed from the upload preview.');
  };

  const loadRecords = async (query = recordsQuery.current, { silent = false } = {}) => {
    recordsQuery.current = query;
    if (!silent) { setLoading(true); setError(''); }
    try {
      const response = await fetch(`${API}/api/admin/submissions?search=${encodeURIComponent(query)}`, { credentials: 'include' });
      if (response.status === 401) { setAuthenticated(false); return; }
      if (!response.ok) throw new Error('Unable to load customer applications.');
      const result = await response.json(); setRecords(result.items); setAuthenticated(true);
    } catch (requestError) { if (!silent) setError(requestError.message); }
    finally { if (!silent) setLoading(false); }
  };

  useEffect(() => { loadRecords(''); }, []);
  useEffect(() => {
    if (authenticated !== true) return undefined;
    const refresh = () => {
      if (!document.hidden) loadRecords(recordsQuery.current, { silent: true });
    };
    const timer = window.setInterval(refresh, 5000);
    document.addEventListener('visibilitychange', refresh);
    window.addEventListener('focus', refresh);
    return () => {
      window.clearInterval(timer);
      document.removeEventListener('visibilitychange', refresh);
      window.removeEventListener('focus', refresh);
    };
  }, [authenticated]);

  const filteredRecords = records.filter(record => {
    if (applicationFilters.status && record.status !== applicationFilters.status) return false;
    if (applicationFilters.reservation && !record.reservation_type.includes(applicationFilters.reservation)) return false;
    const submitted = Date.parse(record.submitted_at);
    if (applicationFilters.dateFrom && submitted < new Date(applicationFilters.dateFrom + 'T00:00:00').getTime()) return false;
    if (applicationFilters.dateTo && submitted > new Date(applicationFilters.dateTo + 'T23:59:59.999').getTime()) return false;
    return true;
  }).sort((a, b) => Date.parse(b.submitted_at) - Date.parse(a.submitted_at));

  const visibleSelectedApplications = filteredRecords.filter(record => selectedApplications.includes(record.application_id));
  const deleteSelectedApplications = async () => {
    const ids = visibleSelectedApplications.map(record => record.application_id);
    if (!ids.length || deletingApplications || !window.confirm(`Delete ${ids.length} selected customer application(s), including their journey details and reservations? This cannot be undone.`)) return;
    setDeletingApplications(true); setError('');
    try {
      const response = await fetch(`${API}/api/admin/submissions/delete`, {
        method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ application_ids: ids }),
      });
      if (response.status === 401) { setAuthenticated(false); throw new Error('Your admin session expired. Please sign in again.'); }
      if (!response.ok) throw new Error('Unable to delete customer applications.');
      setRecords(current => current.filter(record => !ids.includes(record.application_id)));
      setSelectedApplications(current => current.filter(id => !ids.includes(id)));
      setSelected(current => current && ids.includes(current.application_id) ? null : current);
      await loadRecords();
    } catch (failure) { setError(failure.message); }
    finally { setDeletingApplications(false); }
  };

  const pipeline = reservationPipeline(filteredRecords, pipelineCurrency);

  const login = async (event) => {
    event.preventDefault(); setLoading(true); setError('');
    try {
      const response = await fetch(`${API}/api/admin/login`, { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(credentials) });
      if (!response.ok) { const body = await response.json().catch(() => ({})); throw new Error(body.detail || 'Login failed.'); }
      setCredentials({ username: '', password: '' }); await loadRecords();
    } catch (requestError) { setError(requestError.message); setAuthenticated(false); }
    finally { setLoading(false); }
  };

  if (authenticated !== true) return <main className="admin-login"><form onSubmit={login}><div className="admin-brand"><img src={lloydsAuto} alt="Lloyds Auto" /></div><h1>Admin login</h1><p>Sign in to the Customer 360° Dashboard.</p><label>Username<input autoComplete="username" value={credentials.username} onChange={(e) => setCredentials({ ...credentials, username: e.target.value })} required /></label><label>Password<input type="password" autoComplete="current-password" value={credentials.password} onChange={(e) => setCredentials({ ...credentials, password: e.target.value })} required /></label>{error && <p className="admin-error" role="alert">{error}</p>}<button disabled={loading}>{loading ? 'Signing in…' : 'Login'}</button></form></main>;

  return <main className="admin-dashboard">
    <header className="admin-masthead"><div className="admin-masthead-inner"><div className="admin-lloyds-brand" aria-label="Lloyds Auto"><img src={lloydsAuto} alt="Lloyds Auto" /></div><div className="admin-header-actions"><button onClick={async () => { await fetch(`${API}/api/admin/logout`, { method: 'POST', credentials: 'include' }); setAuthenticated(false); }}>Logout</button></div></div></header>
    <section className="admin-dashboard-intro"><h1>Customer 360° Dashboard</h1><p>Review submitted applications, customer details and complete journey selections.</p></section>
    <nav className="admin-tabs" aria-label="Dashboard sections">
      <button type="button" aria-pressed={activeTab === 'applications'} onClick={() => setActiveTab('applications')}>Customer Applications</button>
      <button type="button" aria-pressed={activeTab === 'inventory'} onClick={() => setActiveTab('inventory')}>Inventory</button>
      <button type="button" aria-pressed={activeTab === 'used-contract-hire'} onClick={() => setActiveTab('used-contract-hire')}>Used Contract Hire</button>
      <button type="button" aria-pressed={activeTab === 'contract-purchase'} onClick={() => setActiveTab('contract-purchase')}>Contract Purchase</button>
      <button type="button" aria-pressed={activeTab === 'bca'} onClick={() => setActiveTab('bca')}>BCA 360°</button>
    </nav>
    {activeTab === 'used-contract-hire' && <AdminUsedContractHire api={API} onSessionExpired={expireSession} />}
    {activeTab === 'contract-purchase' && <AdminContractPurchase api={API} onSessionExpired={expireSession} />}
    {activeTab === 'bca' && <AdminBca360 api={API} />}
    <div hidden={activeTab !== 'inventory'}>
      <AdminVehicles api={API} onSessionExpired={expireSession} revision={inventoryRevision} importOpen={importOpen} onToggleImport={() => setImportOpen(value => !value)}>
        {importOpen && <section className="admin-inventory admin-data-import" aria-labelledby="inventory-title">
        <h2 id="inventory-title">Upload inventory</h2>
        <p>Upload the supplied CSV or XLSX inventory file. Existing vehicles are matched by registration; new registrations are added.</p>
        <p className="admin-inventory-help">The template follows the supplied spreadsheet column order. Vehicle fields are mapped to inventory; additional supplier fields are retained in vehicle metadata.</p>
        <p className="admin-inventory-template-link"><a href={`data:text/csv;charset=utf-8,${encodeURIComponent(INVENTORY_HEADERS.map(csvCell).join(',') + '\r\n')}`} download="inventory-template.csv">Download CSV template</a></p>
        <label>Inventory file<input key={inventoryRevision} type="file" accept=".csv,.xlsx" disabled={uploading} onChange={event => { setInventoryFile(event.target.files[0] || null); setInventoryPreview(null); setSelectedInventoryRows([]); setInventoryMessage(''); setInventoryError(''); }} /></label>
        <div className="admin-inventory-actions">
          <button disabled={!inventoryFile || uploading} onClick={() => uploadInventory(true)}>{uploading ? 'Checking…' : 'Review file'}</button>
          <button disabled={!inventoryFile || uploading || !selectedInventoryRows.length || selectedInventoryRows.some(id => !inventoryPreview?.rows.find(row => row.row_number === id)?.valid)} onClick={() => uploadInventory(false, selectedInventoryRows)}>{uploading ? 'Processing…' : 'Import selected'}</button>
          <button type="button" disabled={!selectedInventoryRows.length || uploading} onClick={downloadPreviewSelection}>Download selected CSV</button>
          <button type="button" disabled={!selectedInventoryRows.length || uploading} className="admin-data-delete" onClick={deletePreviewSelection}>Delete selected</button>
        </div>
        {inventoryError && <p className="admin-error" role="alert">{inventoryError}</p>}
        {inventoryMessage && <p className="admin-inventory-success" role="status">{inventoryMessage}</p>}
        {inventoryPreview && <div className="admin-inventory-preview" role="region" aria-label="Inventory upload preview">
          <div className="admin-inventory-preview-heading"><strong>{inventoryPreview.rows.length} rows in preview</strong><span>{inventoryPreview.rows.filter(row => row.valid).length} valid · {inventoryPreview.rows.filter(row => !row.valid).length} with errors</span></div>
          <div className="admin-inventory-preview-scroll"><table><thead><tr><th>Select</th><th>Registration</th><th>Make</th><th>Model</th><th>Year</th><th>Mileage</th><th>P11d value</th><th>Validation</th></tr></thead><tbody>
            {inventoryPreview.rows.map(row => <tr key={row.row_number}><td><input type="checkbox" aria-label={'Select row ' + row.row_number} checked={selectedInventoryRows.includes(row.row_number)} onChange={() => setSelectedInventoryRows(current => current.includes(row.row_number) ? current.filter(value => value !== row.row_number) : [...current, row.row_number])} /></td><td>{row.vehicle?.registration || row.values[0] || '—'}</td><td>{row.vehicle?.manufacturer || '—'}</td><td>{row.vehicle?.model || '—'}</td><td>{row.vehicle?.model_year || '—'}</td><td>{row.vehicle?.mileage ?? '—'}</td><td>{row.vehicle?.list_price ? new Intl.NumberFormat('en-GB', { style: 'currency', currency: 'GBP' }).format(Number(row.vehicle.list_price)) : '—'}</td><td className={row.valid ? 'inventory-preview-valid' : 'inventory-preview-error'}>{row.valid ? 'Ready to import' : row.errors.join('; ')}</td></tr>)}
          </tbody></table></div>
        </div>}
      </section>}
      </AdminVehicles>
    </div>
    <div hidden={activeTab !== 'applications'}>
    <section className="admin-panel admin-applications admin-data-panel"><div className="admin-applications-heading admin-data-heading"><div><h2>Customer applications</h2><p>Review customer details and reservation preferences</p></div><div className="admin-applications-heading-actions admin-data-actions"><span>Summary of {filteredRecords.length} displayed applications</span><button type="button" className="admin-data-delete" disabled={loading || deletingApplications || !visibleSelectedApplications.length} onClick={deleteSelectedApplications}>{deletingApplications ? 'Deleting…' : 'Delete selected'}</button><button type="button" disabled={loading || !filteredRecords.length} onClick={() => downloadApplicationDetails(filteredRecords)}>Download application details</button><button type="button" onClick={() => loadRecords(recordsQuery.current, { silent: true })} disabled={loading}>Refresh</button></div></div>
      {!loading && <>
        <h3>Potential reservation value</h3>
        <p>Gross quoted customer payments if all active reservations in the current results convert.</p>
        <p role="status">{pipeline.quotedCount} of {pipeline.activeCount} active reservations have a usable quote{pipeline.currencies.length > 1 ? ` in ${pipeline.currency}` : ''}.</p>
        {pipeline.currencies.length > 1 && <label> Quote currency <select value={pipeline.currency} onChange={event => setPipelineCurrency(event.target.value)}>
          {pipeline.currencies.map(currency => <option key={currency}>{currency}</option>)}
        </select></label>}
        <AdminDonutReports label="Potential reservation value" charts={pipeline.charts} />
      </>}
      <form className="admin-search admin-data-toolbar" onSubmit={(e) => { e.preventDefault(); loadRecords(search); }}><input aria-label="Search applications" placeholder="Search name, email, company, phone or application ID" value={search} onChange={(e) => setSearch(e.target.value)} /><button>Search</button><button type="button" className="admin-advanced-toggle" aria-expanded={advancedOpen} onClick={() => setAdvancedOpen(open => !open)}>{advancedOpen ? 'Hide filters' : 'Advanced filters'}</button></form>
      {advancedOpen && <form className="admin-application-filters admin-data-filter" onSubmit={event => event.preventDefault()}>
        <label>Status<select value={applicationFilters.status} onChange={event => setApplicationFilters(current => ({ ...current, status: event.target.value }))}><option value="">All statuses</option>{[...new Set(records.map(record => record.status))].sort().map(status => <option key={status} value={status}>{status.replaceAll('_', ' ')}</option>)}</select></label>
        <label>Reservation preference<select value={applicationFilters.reservation} onChange={event => setApplicationFilters(current => ({ ...current, reservation: event.target.value }))}><option value="">All preferences</option><option value="48">48 hours</option><option value="30">30 days</option></select></label>
        <label>Submitted from<input type="date" value={applicationFilters.dateFrom} onChange={event => setApplicationFilters(current => ({ ...current, dateFrom: event.target.value }))} /></label>
        <label>Submitted to<input type="date" value={applicationFilters.dateTo} onChange={event => setApplicationFilters(current => ({ ...current, dateTo: event.target.value }))} /></label>
        <button type="button" onClick={() => setApplicationFilters({ status: '', reservation: '', dateFrom: '', dateTo: '' })}>Clear filters</button>
      </form>}
      <details className="admin-application-columns">
        <summary>Choose columns ({applicationColumns.length}/{APPLICATION_COLUMNS.length})</summary>
        <fieldset>
          <legend>Application fields</legend>
          <div className="admin-application-column-grid">
            {APPLICATION_COLUMNS.map(([key, label]) => (
              <label key={key}><input type="checkbox" checked={applicationColumnKeys.includes(key)} onChange={event => {
                const checked = event.target.checked;
                setApplicationColumnKeys(current => checked ? [...current, key] : current.filter(value => value !== key));
              }} />{label}</label>
            ))}
          </div>
          <div className="admin-application-column-actions">
            <button type="button" onClick={() => setApplicationColumnKeys(APPLICATION_COLUMNS.map(([key]) => key))}>Show all fields</button>
            <button type="button" onClick={() => setApplicationColumnKeys(DEFAULT_APPLICATION_COLUMNS)}>Reset columns</button>
          </div>
        </fieldset>
      </details>
      {error && <p className="admin-error" role="alert">{error}</p>}{loading ? <p>Loading customer applications…</p> : filteredRecords.length === 0 ? <p className="admin-empty">No customer applications match these filters.</p> : <div className="admin-table-wrap admin-applications-table admin-data-table" role="region" aria-label="Customer applications table" tabIndex={0}>
        <table>
          <thead><tr><th scope="col"><input type="checkbox" aria-label="Select all displayed applications" disabled={deletingApplications} checked={filteredRecords.length > 0 && visibleSelectedApplications.length === filteredRecords.length} onChange={event => setSelectedApplications(event.target.checked ? filteredRecords.map(record => record.application_id) : [])} /></th>{applicationColumns.map(([key, label]) => <th key={key} scope="col">{label}</th>)}<th scope="col" aria-label="Actions"></th></tr></thead>
          <tbody>{filteredRecords.map(record => (
            <tr key={record.application_id}>
              <td><input type="checkbox" aria-label={`Select application ${record.application_id}`} disabled={deletingApplications} checked={selectedApplications.includes(record.application_id)} onChange={() => setSelectedApplications(current => current.includes(record.application_id) ? current.filter(id => id !== record.application_id) : [...current, record.application_id])} /></td>
              {applicationColumns.map(([key, , render]) => (
                <td key={key} className={key === 'application_id' || key === 'customer_id' ? 'admin-id' : undefined}>
                  {(render ? render(record) : record[key]) ?? '—'}
                </td>
              ))}
              <td><button onClick={() => setSelected(record)}>View details</button></td>
            </tr>
          ))}</tbody>
        </table>
      </div>}
    </section>
    {selected && <ApplicationDetailsDialog record={selected} onClose={() => setSelected(null)} />}
    </div>
  </main>;
}
