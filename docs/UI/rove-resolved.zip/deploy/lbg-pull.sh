#!/usr/bin/env bash
# Usage: bash deploy/lbg-pull.sh [LBG_BRANCH] [NEW_PERSONAL_BRANCH]
# Merge both histories through the shared helper; do not restore snapshot copying.
set -euo pipefail
script_dir=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
exec bash "$script_dir/lbg-sync.sh" pull "$@"
