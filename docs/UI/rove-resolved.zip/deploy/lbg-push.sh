#!/usr/bin/env bash
# Usage: bash deploy/lbg-push.sh [NEW_LBG_FEATURE_BRANCH]
# Destination base is LBG main_stage. Source is personal main.
# Preserve both contributors' history through the shared merge-based sync helper.
set -euo pipefail
script_dir=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
exec bash "$script_dir/lbg-sync.sh" push "$@"
